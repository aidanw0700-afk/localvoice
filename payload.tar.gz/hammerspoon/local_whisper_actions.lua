-- Copy to: ~/.hammerspoon/local_whisper_actions.lua
-- Voice commands for local-whisper dictation.
-- All commands start with "voice command" to prevent false matches on normal speech.
--
-- Hooks:
--   beforeInsert(ctx)  -> runs before text insertion
--   actions = { ... }  -> ordered list of actions
--   afterInsert(ctx)   -> runs after insertion
--
-- Context fields:
--   ctx.text, ctx.textLower, ctx.originalText
--   ctx.lang, ctx.outputMode
--   ctx.appName, ctx.appBundleID   -- app that was focused when recording started
--   ctx.insert, ctx.inserted, ctx.handled
--   ctx.timestamp, ctx.isoTime     -- when the dictation was recorded
--
-- Context methods:
--   ctx:setText("new text")
--   ctx:disableInsert(), ctx:enableInsert()
--   ctx:launchApp("Safari")
--   ctx:appendToFile(path, line)
--   ctx:runShell("command", optionalInputText)
--   ctx:keystroke({"cmd"}, "a")      -- fire a keystroke
--   ctx:notify("message"), ctx:log("message")
--
-- Patterns match against ctx.textLower (case-insensitive).
-- Set ctx.handled = true in any hook to skip remaining actions.
-- Config auto-reloads when the file changes.

local HOME = os.getenv("HOME")

return {
    beforeInsert = function(ctx)

        -- ── Command Mode (added Jul 7 2026) ──────────────────────────────
        -- Highlight text anywhere, hold the trigger key, start with a rewrite
        -- verb: "make this formal", "fix this", "shorten this to one sentence",
        -- "rewrite this as bullet points", "translate this to spanish"…
        -- The selection goes to local Ollama with the spoken instruction and
        -- the rewrite replaces it in place. No selection -> normal dictation.
        -- (Plain respeak-over needs no command: pasting replaces a selection.)
        local isCommand = ctx.textLower:match("^%s*rewrite this")
            or ctx.textLower:match("^%s*edit this")
            or ctx.textLower:match("^%s*make this")
            or ctx.textLower:match("^%s*fix this")
            or ctx.textLower:match("^%s*reword this")
            or ctx.textLower:match("^%s*shorten this")
            or ctx.textLower:match("^%s*expand this")
            or ctx.textLower:match("^%s*translate this")
            or ctx.textLower:match("^%s*summarize this")
        if isCommand then
            local sentinel = "\226\159\170lw-no-selection\226\159\171"
            local oldClip = hs.pasteboard.getContents()
            hs.pasteboard.setContents(sentinel)
            ctx:keystroke({"cmd"}, "c")
            hs.timer.usleep(250000)  -- let the clipboard catch up
            local selection = hs.pasteboard.getContents()
            if selection and selection ~= sentinel and selection ~= "" then
                ctx:notify("Command mode: rewriting selection…")
                local payload = hs.json.encode({
                    model = "gemma3:4b",
                    prompt = "You rewrite text. Apply the INSTRUCTION to the TEXT. Respond with "
                        .. "the rewritten text and NOTHING else - never acknowledge, never ask "
                        .. "questions, never explain. If the instruction cannot be applied, "
                        .. "return the TEXT unchanged.\n\nTEXT:\n" .. selection
                        .. "\n\nINSTRUCTION: " .. ctx.originalText
                        .. "\n\nREWRITTEN TEXT:",
                    stream = false,
                    options = { temperature = 0.2 },
                })
                local tmp = os.tmpname()
                local f = io.open(tmp, "w"); f:write(payload); f:close()
                local out = hs.execute("curl -s --max-time 60 http://localhost:11434/api/generate -d @" .. tmp)
                os.remove(tmp)
                local ok, resp = pcall(hs.json.decode, out)
                local result = ok and resp and resp.response
                    and resp.response:gsub("^%s+", ""):gsub("%s+$", "") or ""
                result = result:gsub('^"(.*)"$', "%1")  -- unwrap if the model quoted it
                -- Chattiness guard: never paste a conversational reply over real text
                local rl = result:lower()
                local chatty = result == ""
                    or rl:match("^okay") or rl:match("^ok[,%. ]") or rl:match("^sure")
                    or rl:match("^here") or rl:match("^certainly") or rl:match("^got it")
                    or rl:match("^i%s") or rl:match("^i'") or rl:match("^please")
                    or rl:match("highlight what") or rl:match("provide the text")
                if not chatty then
                    ctx:setText(result)
                    ctx.handled = true  -- insertion pastes the rewrite over the selection
                    return
                elseif result ~= "" then
                    hs.pasteboard.setContents(oldClip or "")
                    ctx:disableInsert()
                    ctx:notify("Model got chatty — selection untouched, try again")
                    ctx.handled = true
                    return
                else
                    hs.pasteboard.setContents(oldClip or "")
                    ctx:disableInsert()
                    ctx:notify("Command mode failed — is Ollama running?")
                    ctx.handled = true
                    return
                end
            else
                hs.pasteboard.setContents(oldClip or "")
                -- no selection: fall through, treat as normal dictation
            end
        end

        -- "voice command cancel/abort" — can appear anywhere in the text
        local stripped = ctx.textLower:gsub("[%.%,%!%?]+$", "")
        if stripped:match("voice%s+command%s+cancel%s*$")
            or stripped:match("voice%s+command%s+abort%s*$") then
            ctx:disableInsert()
            ctx:notify("Dictation discarded")
            ctx.handled = true
            return
        end

        -- All other commands require "voice command" at the start
        local action = stripped:match("^voice%s+command%s+(.+)$")
        if not action then return end

        -- "voice command note <anything>" — save to ~/whisper_notes.md
        local note = action:match("^note[%s%p]+(.+)$")
        if note then
            local origStripped = ctx.text:gsub("[%.%,%!%?]+$", "")
            local content = origStripped:match("%w+%s+%w+%s+%w+[%s%p]+(.+)$") or note
            ctx:appendToFile(HOME .. "/whisper_notes.md", "- " .. content)
            ctx:disableInsert()
            ctx:notify("Note saved: " .. content)
            ctx.handled = true
            return
        end

        -- "voice command remind <anything>" — create a macOS Reminder
        local reminder = action:match("^remind[%s%p]+(.+)$")
            or action:match("^reminder[%s%p]+(.+)$")
        if reminder then
            local origStripped = ctx.text:gsub("[%.%,%!%?]+$", "")
            local content = origStripped:match("%w+%s+%w+%s+%w+[%s%p]+(.+)$") or reminder
            local script = string.format(
                'tell application "Reminders" to make new reminder with properties {name:"%s"}',
                content:gsub('"', '\\"')
            )
            ctx:runShell("osascript -e '" .. script:gsub("'", "'\\''") .. "'")
            ctx:launchApp("Reminders")
            ctx:disableInsert()
            ctx:notify("Reminder added: " .. content)
            ctx.handled = true
            return
        end

        -- "voice command open app <name>" — launch or focus an app
        local app = action:match("^open%s+app%s+(.+)$")
        if app then
            local origStripped = ctx.text:gsub("[%.%,%!%?]+$", "")
            local origApp = origStripped:match("%w+%s+%w+%s+%w+%s+%w+%s+(.+)$") or app
            origApp = origApp:gsub("[%s]+$", "")
            ctx:launchApp(origApp)
            ctx:disableInsert()
            ctx.handled = true
            return
        end

        -- "voice command select all" — Cmd+A
        if action == "select all" then
            ctx:disableInsert()
            ctx:keystroke({"cmd"}, "a")
            ctx.handled = true
            return
        end

        -- "voice command copy" — Cmd+C
        if action == "copy" or action == "copy that" then
            ctx:disableInsert()
            ctx:keystroke({"cmd"}, "c")
            ctx:notify("Copied")
            ctx.handled = true
            return
        end

        -- "voice command paste" — Cmd+V
        if action == "paste" or action == "paste that" then
            ctx:disableInsert()
            ctx:keystroke({"cmd"}, "v")
            ctx.handled = true
            return
        end

        -- "voice command undo" — Cmd+Z
        if action == "undo" then
            ctx:disableInsert()
            ctx:keystroke({"cmd"}, "z")
            ctx.handled = true
            return
        end

    end,

    actions = {},

    afterInsert = function(ctx)
        if ctx.inserted then
            ctx:log("inserted [" .. (ctx.appName or "?") .. "]: " .. ctx.text)
        elseif ctx.handled then
            ctx:log("command [" .. (ctx.appName or "?") .. "]: " .. ctx.originalText)
        end
    end,
}
