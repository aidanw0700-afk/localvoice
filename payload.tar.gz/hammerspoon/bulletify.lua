-- ~/.hammerspoon/bulletify.lua
-- Highlight text anywhere → press the hotkey → local Ollama turns it into
-- concise bullet points and pastes them over the selection. No voice needed.
-- Companion to the command mode in local_whisper_actions.lua.

local M = {}

-- ── Config ──────────────────────────────────────────────────────────
local HOTKEY_MODS = { "cmd", "alt" }   -- ⌘⌥8  (⌥8 types "•" — easy to remember)
local HOTKEY_KEY  = "8"
local MODEL       = "gemma3:4b"        -- same model as voice command mode
local BULLET      = "- "               -- markdown-style; change to "• " if you prefer

local PROMPT_TEMPLATE = "You convert text into concise bullet points. Rewrite the TEXT "
    .. "as a short list of bullet points. Each bullet starts with exactly \"" .. BULLET .. "\" "
    .. "on its own line. Keep every key fact, drop filler, one idea per bullet. "
    .. "Respond with ONLY the bullet list - never acknowledge, never ask questions, "
    .. "never explain.\n\nTEXT:\n%s\n\nBULLET POINTS:"

-- ── Implementation ──────────────────────────────────────────────────
local function notify(msg)
    hs.notify.new({ title = "bulletify", informativeText = msg }):send()
end

local function bulletify()
    -- Grab the current selection via Cmd+C, using a sentinel so we can
    -- tell "nothing selected" apart from "clipboard already had text".
    local sentinel = "\226\159\170bulletify-no-selection\226\159\171"
    local oldClip = hs.pasteboard.getContents()
    hs.pasteboard.setContents(sentinel)
    hs.eventtap.keyStroke({ "cmd" }, "c")
    hs.timer.usleep(250000)  -- let the clipboard catch up
    local selection = hs.pasteboard.getContents()

    if not selection or selection == sentinel or selection == "" then
        hs.pasteboard.setContents(oldClip or "")
        notify("Nothing selected — highlight text first")
        return
    end

    notify("Bulletifying…")
    local payload = hs.json.encode({
        model = MODEL,
        prompt = string.format(PROMPT_TEMPLATE, selection),
        stream = false,
        options = { temperature = 0.2 },
    })
    local tmp = os.tmpname()
    local f = io.open(tmp, "w"); f:write(payload); f:close()

    -- Async so the UI never freezes while the model thinks
    hs.task.new("/usr/bin/curl", function(exitCode, stdout)
        os.remove(tmp)
        local ok, resp = pcall(hs.json.decode, stdout or "")
        local result = ok and resp and resp.response
            and resp.response:gsub("^%s+", ""):gsub("%s+$", "") or ""
        result = result:gsub('^"(.*)"$', "%1")

        -- Chattiness guard: never paste a conversational reply over real text
        local rl = result:lower()
        local chatty = result == ""
            or rl:match("^okay") or rl:match("^ok[,%. ]") or rl:match("^sure")
            or rl:match("^here") or rl:match("^certainly") or rl:match("^got it")
            or rl:match("^i%s") or rl:match("^i'") or rl:match("^please")

        if chatty then
            hs.pasteboard.setContents(oldClip or "")
            if result == "" then
                notify("Failed — is Ollama running? (ollama serve)")
            else
                notify("Model got chatty — selection untouched, try again")
            end
            return
        end

        -- Paste the bullets over the selection, then restore the clipboard
        hs.pasteboard.setContents(result)
        hs.eventtap.keyStroke({ "cmd" }, "v")
        hs.timer.doAfter(0.4, function()
            hs.pasteboard.setContents(oldClip or "")
        end)
    end, { "-s", "--max-time", "60",
           "http://localhost:11434/api/generate", "-d", "@" .. tmp }):start()
end

M.hotkey = hs.hotkey.bind(HOTKEY_MODS, HOTKEY_KEY, bulletify)

return M
